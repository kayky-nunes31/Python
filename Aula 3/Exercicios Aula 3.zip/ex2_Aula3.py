valor_hrs = int(input("Indique o valor em horas desejadas: "))

hrs_min = valor_hrs * 60

print(f"Esse é o valor de Horas {valor_hrs} e esse é o Valor de HorasMinuto {hrs_min}")

input("Conferindo")