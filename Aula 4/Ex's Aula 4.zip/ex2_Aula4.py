turno = input("Digite o seu turno de trabalho entre 1, 2 e 3: ")
qtd_horas = float(input("Digite a quantidade de horas de seu turno: "))

if turno == 1:
    salario = 37.50 * qtd_horas
    print("O seu sálario é %.2f" % (salario))

if turno == 2:
    salario = 37.50 * qtd_horas
    print("O seu sálario é %.2f" % (salario))

if turno == 3:
    salario = 45.00 * qtd_horas
    print("O seu sálario é %.2f" % (salario))