num = int(input("Digite um número inteiro: "))

if num >= 0 and num <= 9:
    print(f"Valor CORRETO!!!")
else:
    print("Valor INCORRETO, por favor tente outro número")

input("Conferindo")