valor = float(input("Digite o valor em dólar para que aja a conversão: "))
dolar = float(5.11)

conversao = valor * dolar

print(f"O valor da contação de dólar para real é: {conversao}")

input("Conferindo")