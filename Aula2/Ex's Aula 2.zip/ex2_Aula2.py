salario = float(input("Digite o seu salário atual: "))

acrescido = salario * 0.05

print(f"Sua comissão é de {acrescido}")

input("Conferindo")