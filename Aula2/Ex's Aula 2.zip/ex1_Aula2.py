lado = float(input("Digite o valor do lado do retângulo: "))
base = float(input("Digite o valor da base do retângulo: "))

area = lado * base

print(f"O resultado do cálculo da área do retângulo é: {area}")

input("Conferindo")