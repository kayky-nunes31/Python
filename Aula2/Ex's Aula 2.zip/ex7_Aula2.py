# Convertendo Temperatura Cº

tc = float(input("Digite o valor da temperatura: "))

print(f"Essa é a temperatura em Celsius: {tc}º")


# Convertendo em Kelvin
tk = tc + 273

print(f"Esse é o valor da temperatura em Kelvin: {tk}º")


# Convertendo em Farenheit
tf = (1.8 * tc) + 32

print(f"Esse é o valor da temperatura em Farenheit: {tf}º")

input("Conferindo")