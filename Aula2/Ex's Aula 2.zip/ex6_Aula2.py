valor_cliente = float(input("Digite o valor realizado pelo cliente no Restaurante ComaBem: "))

garcom = valor_cliente * 0.10

print(f"O garçom vai receber {garcom}")

input("Conferindo")