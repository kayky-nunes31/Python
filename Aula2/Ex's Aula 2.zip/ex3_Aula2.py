distancia = float(input("Digite a distância entre as cidades: "))
tempo = float(input("Digite o tempo de percurso: "))

vm = distancia / tempo

print(f"A velocidade média entre uma cidade e a outra é: {vm}")

input("Conferindo")