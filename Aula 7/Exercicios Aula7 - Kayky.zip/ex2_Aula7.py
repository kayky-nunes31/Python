for i in range(0, 53):
    print(i, end=' ')
for i in range(54, 102, 2):
    print(i, end=' ')