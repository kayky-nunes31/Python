for i in range(0, 100, 2):
    print(i, end=' ')